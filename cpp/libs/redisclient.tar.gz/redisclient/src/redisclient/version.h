/*
 * Copyright (C) Alex Nekipelov (alex@nekipelov.net)
 * License: MIT
 */

#ifndef REDISCLIENT_VERSION_H
#define REDISCLIENT_VERSION_H

#define REDIS_CLIENT_VERSION 600 // 0.6.0

#endif // REDISCLIENT_VERSION_H
